// scripts/birthday.js
function flipCard() {
    const cardInner = document.getElementById('card-inner');
    cardInner.classList.toggle('card-flip');
}
